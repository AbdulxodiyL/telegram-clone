const express = require('express');
require('dotenv').config();
const cors = require('cors');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
    console.log("📁 'uploads' papkasi yaratildi!");
}
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const io = new Server(server, {
    cors: {
        origin: 'http://localhost:5173',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        credentials: true,
    },
});

app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());

app.use('/uploads', express.static(uploadDir));

const authRouter = require('./app/router/auth.router');
const chatRouter = require('./app/router/chat.router');

app.use('/api/auth', authRouter);
app.use('/api/chat', chatRouter);

app.get('/', (req, res) => {
    res.send('✅ Express server ishlayapti!');
});

io.on('connection', (socket) => {
    console.log('🟢 Yangi foydalanuvchi ulandi:', socket.id);

    socket.on('registerUser', (userId) => {
        socket.userId = userId;
        console.log(`📱 Foydalanuvchi ro‘yxatdan o‘tdi: ${userId}`);
    });

    socket.on('sendMessage', async (data) => {
        try {
            const Chat = require('./app/models/chat.models');
            const chat = await Chat.create(data);

            socket.broadcast.emit('receiveMessage', chat);


        } catch (err) {
            console.error('❌ Xabar yuborishda xatolik:', err.message);
        }
    });

    socket.on('disconnect', () => {
        console.log('🔴 Foydalanuvchi chiqdi:', socket.id);
    });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    console.log(`🚀 Server http://localhost:${PORT} da ishlayapti`);
});
