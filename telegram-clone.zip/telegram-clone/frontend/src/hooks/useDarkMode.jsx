// hooks/useDarkMode.js
import { useState, useEffect } from 'react';

export const useDarkMode = () => {
    const [darkMode, setDarkMode] = useState(() => {
        const saved = localStorage.getItem("darkMode");
        return saved ? JSON.parse(saved) : false;
    });

    useEffect(() => {
        localStorage.setItem("darkMode", JSON.stringify(darkMode));

        // Document body ga dark mode class qo'shish/olib tashlash
        if (darkMode) {
            document.body.classList.add('dark-mode');
            document.body.style.backgroundColor = '#0a0a0a';
            document.body.style.color = '#ffffff';
        } else {
            document.body.classList.remove('dark-mode');
            document.body.style.backgroundColor = '#f8fafc';
            document.body.style.color = '';
        }
    }, [darkMode]);

    const toggleDarkMode = () => {
        setDarkMode(prev => !prev);
    };

    return { darkMode, setDarkMode, toggleDarkMode };
};