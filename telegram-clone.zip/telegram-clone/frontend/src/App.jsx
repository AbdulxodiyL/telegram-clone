import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import ChatPage from "./pages/ChatPage";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import SettingsPage from "./components/SettingsPage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Routes>
    </BrowserRouter>
  );
}
