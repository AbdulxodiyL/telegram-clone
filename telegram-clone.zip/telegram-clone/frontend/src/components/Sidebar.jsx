import {
    Box,
    List,
    ListItem,
    ListItemText,
    Typography,
    ListItemAvatar,
    Avatar,
    Badge,
    useTheme,
    useMediaQuery
} from "@mui/material";
import {
    FiberManualRecord,
    Groups,
    People,
    Campaign,
    Chat
} from "@mui/icons-material";
import { useState } from 'react';

export default function Sidebar({
    users,
    onSelectUser,
    selectedUser,
    darkMode = false,
    currentUser
}) {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));
    const [activeTab, setActiveTab] = useState('contacts');

    // Color functions for dark/light mode
    const getTextColor = () => darkMode ? '#ffffff' : '#1a1a1a';
    const getSecondaryTextColor = () => darkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
    const getBorderColor = () => darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)';
    const getPaperBackground = () => darkMode
        ? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
        : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)';
    const getSurfaceColor = () => darkMode
        ? 'rgba(30, 30, 30, 0.95)'
        : 'rgba(255, 255, 255, 0.95)';
    const getActiveTabColor = () => darkMode
        ? 'linear-gradient(45deg, rgba(0, 136, 204, 0.3), rgba(0, 162, 255, 0.3))'
        : 'linear-gradient(45deg, rgba(0, 136, 204, 0.15), rgba(0, 162, 255, 0.15))';

    // Navigation tabs
    const tabs = [
        { id: 'contacts', icon: People, label: 'Kontaktlar', count: users.length },
        { id: 'groups', icon: Groups, label: 'Guruhlar', count: 3 },
        { id: 'channels', icon: Campaign, label: 'Kanalalar', count: 5 }
    ];

    return (
        <Box
            sx={{
                width: isMobile ? "100%" : "450px",
                background: getPaperBackground(),
                backdropFilter: 'blur(20px)',
                borderRight: `1px solid ${getBorderColor()}`,
                boxShadow: darkMode
                    ? '8px 0 30px rgba(0, 0, 0, 0.4)'
                    : '8px 0 30px rgba(0, 0, 0, 0.1)',
                display: "flex",
                height: "100vh",
                position: isMobile ? 'relative' : 'fixed',
                left: 0,
                top: 0,
                zIndex: 1000,
                transition: 'all 0.3s ease'
            }}
        >
            {/* Navigation Sidebar */}
            <Box
                sx={{
                    width: "70px",
                    background: darkMode
                        ? 'linear-gradient(135deg, #151515 0%, #1e1e1e 100%)'
                        : 'linear-gradient(135deg, #f0f4f8 0%, #e8ecef 100%)',
                    borderRight: `1px solid ${getBorderColor()}`,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    py: 2,
                    gap: 1
                }}
            >
                {tabs.map((tab) => {
                    const IconComponent = tab.icon;
                    const isActive = activeTab === tab.id;

                    return (
                        <Box
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            sx={{
                                width: "44px",
                                height: "44px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                borderRadius: "12px",
                                cursor: "pointer",
                                position: "relative",
                                background: isActive ? getActiveTabColor() : 'transparent',
                                border: isActive
                                    ? `1px solid ${darkMode ? 'rgba(0, 136, 204, 0.5)' : 'rgba(0, 136, 204, 0.3)'}`
                                    : '1px solid transparent',
                                '&:hover': {
                                    background: darkMode
                                        ? 'rgba(255, 255, 255, 0.1)'
                                        : 'rgba(0, 0, 0, 0.05)',
                                },
                                transition: 'all 0.2s ease',
                                mb: 0.5
                            }}
                        >
                            <IconComponent
                                sx={{
                                    fontSize: "24px",
                                    color: isActive
                                        ? '#0088cc'
                                        : getSecondaryTextColor()
                                }}
                            />

                            {/* Badge for counts */}
                            {tab.count > 0 && (
                                <Box
                                    sx={{
                                        position: "absolute",
                                        top: "-4px",
                                        right: "-4px",
                                        background: '#ff4757',
                                        color: 'white',
                                        borderRadius: "10px",
                                        width: "18px",
                                        height: "18px",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        fontSize: "10px",
                                        fontWeight: "bold",
                                        border: `2px solid ${darkMode ? '#151515' : '#f0f4f8'}`
                                    }}
                                >
                                    {tab.count > 9 ? '9+' : tab.count}
                                </Box>
                            )}
                        </Box>
                    );
                })}

                {/* Divider */}
                <Box
                    sx={{
                        width: "30px",
                        height: "1px",
                        background: getBorderColor(),
                        my: 2
                    }}
                />

                {/* Current User Avatar */}
                <Box
                    sx={{
                        width: "44px",
                        height: "44px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        borderRadius: "12px",
                        cursor: "pointer",
                        background: darkMode
                            ? 'rgba(255, 255, 255, 0.1)'
                            : 'rgba(0, 0, 0, 0.05)',
                        '&:hover': {
                            background: darkMode
                                ? 'rgba(255, 255, 255, 0.15)'
                                : 'rgba(0, 0, 0, 0.08)',
                        },
                        mt: 'auto'
                    }}
                >
                    <Avatar
                        sx={{
                            width: "32px",
                            height: "32px",
                            background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                            fontWeight: 'bold',
                            fontSize: '0.9rem'
                        }}
                    >
                        {currentUser?.username?.charAt(0).toUpperCase()}
                    </Avatar>
                </Box>
            </Box>

            {/* Main Content Area */}
            <Box
                sx={{
                    flex: 1,
                    display: "flex",
                    flexDirection: "column",
                    overflow: "hidden"
                }}
            >
                {/* Header Section */}
                <Box sx={{ p: 2, pb: 1 }}>
                    <Typography
                        variant="h6"
                        sx={{
                            color: getTextColor(),
                            fontWeight: 700,
                            fontSize: '1.2rem',
                            mb: 1
                        }}
                    >
                        {tabs.find(tab => tab.id === activeTab)?.label}
                    </Typography>
                    <Typography
                        variant="body2"
                        sx={{
                            color: getSecondaryTextColor(),
                            mb: 2
                        }}
                    >
                        {activeTab === 'contacts' && `${users.length} ta foydalanuvchi`}
                        {activeTab === 'groups' && `3 ta guruh`}
                        {activeTab === 'channels' && `5 ta kanal`}
                    </Typography>
                </Box>

                {/* Content Area with Scroll */}
                <Box sx={{
                    flex: 1,
                    overflowY: "auto",
                    '&::-webkit-scrollbar': {
                        width: '6px',
                    },
                    '&::-webkit-scrollbar-track': {
                        background: darkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                        borderRadius: '3px',
                    },
                    '&::-webkit-scrollbar-thumb': {
                        background: darkMode ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)',
                        borderRadius: '3px',
                    },
                    '&::-webkit-scrollbar-thumb:hover': {
                        background: darkMode ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)',
                    }
                }}>
                    {activeTab === 'contacts' && (
                        <List sx={{ p: 0 }}>
                            {users.map((user) => (
                                <ListItem
                                    key={user.id}
                                    button
                                    selected={selectedUser?.id === user.id}
                                    onClick={() => onSelectUser(user)}
                                    sx={{
                                        px: 2,
                                        py: 1.5,
                                        borderBottom: '1px solid',
                                        borderColor: getBorderColor(),
                                        '&:hover': {
                                            background: darkMode
                                                ? 'linear-gradient(45deg, rgba(0, 136, 204, 0.2), rgba(0, 162, 255, 0.2))'
                                                : 'linear-gradient(45deg, rgba(0, 136, 204, 0.1), rgba(0, 162, 255, 0.1))',
                                            transform: 'translateX(4px)',
                                        },
                                        '&.Mui-selected': {
                                            background: 'linear-gradient(45deg, rgba(0, 136, 204, 0.25), rgba(0, 162, 255, 0.25))',
                                            borderRight: '3px solid #0088cc',
                                            '&:hover': {
                                                background: 'linear-gradient(45deg, rgba(0, 136, 204, 0.3), rgba(0, 162, 255, 0.3))',
                                            }
                                        },
                                        transition: 'all 0.3s ease',
                                        color: getTextColor(),
                                        backdropFilter: 'blur(10px)'
                                    }}
                                >
                                    <ListItemAvatar>
                                        <Badge
                                            overlap="circular"
                                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                            variant="dot"
                                            sx={{
                                                '& .MuiBadge-dot': {
                                                    backgroundColor: '#4ade80',
                                                    width: 12,
                                                    height: 12,
                                                    borderRadius: '50%',
                                                    border: `2px solid ${darkMode ? '#1a1a1a' : 'white'}`
                                                }
                                            }}
                                        >
                                            <Avatar
                                                sx={{
                                                    width: 48,
                                                    height: 48,
                                                    background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                                                    fontWeight: 'bold',
                                                    fontSize: '1.2rem',
                                                    boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)'
                                                }}
                                            >
                                                {user.username?.charAt(0).toUpperCase()}
                                            </Avatar>
                                        </Badge>
                                    </ListItemAvatar>

                                    <ListItemText
                                        primary={
                                            <Typography
                                                variant="body1"
                                                sx={{
                                                    fontWeight: 600,
                                                    color: getTextColor()
                                                }}
                                            >
                                                {user.username}
                                            </Typography>
                                        }
                                        secondary={
                                            <Typography
                                                variant="caption"
                                                sx={{
                                                    color: getSecondaryTextColor(),
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: 0.5
                                                }}
                                            >
                                                <FiberManualRecord sx={{ fontSize: 10 }} />
                                                Online
                                            </Typography>
                                        }
                                    />
                                </ListItem>
                            ))}
                        </List>
                    )}

                    {/* Groups Tab Content */}
                    {activeTab === 'groups' && (
                        <Box sx={{ p: 2 }}>
                            <Typography variant="body1" sx={{ color: getSecondaryTextColor(), textAlign: 'center' }}>
                                Guruhlar tez orada qo'shiladi
                            </Typography>
                        </Box>
                    )}

                    {/* Channels Tab Content */}
                    {activeTab === 'channels' && (
                        <Box sx={{ p: 2 }}>
                            <Typography variant="body1" sx={{ color: getSecondaryTextColor(), textAlign: 'center' }}>
                                Kanalalar tez orada qo'shiladi
                            </Typography>
                        </Box>
                    )}

                    {/* Empty State for Contacts */}
                    {activeTab === 'contacts' && users.length === 0 && (
                        <Box
                            textAlign="center"
                            sx={{
                                p: 4,
                                color: getSecondaryTextColor()
                            }}
                        >
                            <People sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
                            <Typography variant="body1">
                                Hozircha kontaktlar mavjud emas
                            </Typography>
                        </Box>
                    )}
                </Box>
            </Box>
        </Box>
    );
}