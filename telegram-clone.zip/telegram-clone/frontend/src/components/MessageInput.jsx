import { Box, TextField, IconButton, Paper, Popover } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import EmojiEmotionsIcon from "@mui/icons-material/EmojiEmotions";
import { useState, useRef } from "react";

// Oddiy emoji lar ro'yxati
const EMOJIS = [
    '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
    '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
    '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
    '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
    '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
    '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗',
    '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯',
    '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐',
    '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '😈',
    '👿', '👹', '👺', '🤡', '💩', '👻', '💀', '☠️', '👽', '👾',
    '🤖', '🎃', '😺', '😸', '😹', '😻', '😼', '😽', '🙀', '😿',
    '😾', '👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏', '✌️',
    '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️',
    '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲',
    '🤝', '🙏', '✍️', '💅', '🤳', '💪', '🦾', '🦵', '🦿', '🦶',
    '👣', '👂', '🦻', '👃', '🧠', '🦷', '🦴', '👀', '👁️', '👅',
    '👄', '💋', '🩸', '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤',
    '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘',
    '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '🕎',
    '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍',
    '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️',
    '☣️', '📴', '📳', '🈶', '🈚', '🈸', '🈺', '🈷️', '✴️', '🆚'
];

export default function MessageInput({ onSend, darkMode }) {
    const [message, setMessage] = useState("");
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const textFieldRef = useRef(null);

    const handleSend = () => {
        if (message.trim() !== "") {
            onSend(message);
            setMessage("");
            setShowEmojiPicker(false); // Xabar yuborilganda emoji panelini yopish
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    // Emoji tanlash funksiyasi
    const handleEmojiClick = (emoji) => {
        const input = textFieldRef.current;
        if (input) {
            const start = input.selectionStart;
            const end = input.selectionEnd;
            const newMessage = message.substring(0, start) + emoji + message.substring(end);
            setMessage(newMessage);

            // Kursorni emoji dan keyingi joyga o'tkazish
            setTimeout(() => {
                input.focus();
                input.setSelectionRange(start + emoji.length, start + emoji.length);
            }, 0);
        }
    };

    // Emoji panelini ochish/yopish
    const toggleEmojiPicker = () => {
        setShowEmojiPicker(!showEmojiPicker);
    };

    // Dark mode uchun ranglar
    const getBackgroundColor = () => {
        return darkMode
            ? 'rgba(30, 30, 30, 0.95)'
            : 'rgba(255, 255, 255, 0.95)';
    };

    const getBorderColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)';
    };

    const getTextColor = () => {
        return darkMode ? '#ffffff' : '#1a1a1a';
    };

    const getSecondaryTextColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
    };

    const getHoverBackground = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)';
    };

    const getEmojiBackground = () => {
        return darkMode
            ? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
            : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)';
    };

    return (
        <Paper
            elevation={3}
            sx={{
                background: getBackgroundColor(),
                borderTop: `1px solid ${getBorderColor()}`,
                borderRadius: 0,
                boxShadow: '0 -2px 10px rgba(0, 0, 0, 0.1)',
                overflow: 'hidden'
            }}
        >
            {/* Emoji Picker */}
            {showEmojiPicker && (
                <Box
                    sx={{
                        p: 2,
                        background: getEmojiBackground(),
                        borderBottom: `1px solid ${getBorderColor()}`,
                        maxHeight: 200,
                        overflowY: 'auto'
                    }}
                >
                    <Box
                        sx={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(8, 1fr)',
                            gap: 1,
                        }}
                    >
                        {EMOJIS.map((emoji, index) => (
                            <IconButton
                                key={index}
                                onClick={() => handleEmojiClick(emoji)}
                                sx={{
                                    fontSize: '1.5rem',
                                    width: 40,
                                    height: 40,
                                    '&:hover': {
                                        background: darkMode
                                            ? 'rgba(255, 255, 255, 0.1)'
                                            : 'rgba(0, 0, 0, 0.1)',
                                        transform: 'scale(1.2)',
                                    },
                                    transition: 'all 0.2s ease',
                                }}
                            >
                                {emoji}
                            </IconButton>
                        ))}
                    </Box>
                </Box>
            )}

            {/* Input qismi */}
            <Box sx={{ p: 2 }}>
                <Box display="flex" alignItems="center" gap={1}>
                    {/* Fayl yuborish tugmasi */}
                    <IconButton
                        sx={{
                            color: getSecondaryTextColor(),
                            '&:hover': {
                                background: getHoverBackground(),
                                transform: 'scale(1.1)'
                            },
                            transition: 'all 0.2s ease'
                        }}
                    >
                        <AttachFileIcon />
                    </IconButton>

                    {/* Emoji tugmasi */}
                    <IconButton
                        onClick={toggleEmojiPicker}
                        sx={{
                            color: showEmojiPicker ? '#0088cc' : getSecondaryTextColor(),
                            background: showEmojiPicker ?
                                (darkMode ? 'rgba(0, 136, 204, 0.2)' : 'rgba(0, 136, 204, 0.1)') : 'transparent',
                            '&:hover': {
                                background: getHoverBackground(),
                                transform: 'scale(1.1)'
                            },
                            transition: 'all 0.2s ease'
                        }}
                    >
                        <EmojiEmotionsIcon />
                    </IconButton>

                    {/* Xabar inputi */}
                    <TextField
                        fullWidth
                        variant="outlined"
                        placeholder="Xabar yozing..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyPress={handleKeyPress}
                        multiline
                        maxRows={3}
                        inputRef={textFieldRef}
                        sx={{
                            '& .MuiOutlinedInput-root': {
                                color: getTextColor(),
                                background: darkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.03)',
                                borderRadius: 3,
                                '& fieldset': {
                                    borderColor: getBorderColor(),
                                },
                                '&:hover fieldset': {
                                    borderColor: darkMode ? 'rgba(255, 255, 255, 0.3)' : 'rgba(0, 0, 0, 0.3)',
                                },
                                '&.Mui-focused fieldset': {
                                    borderColor: '#0088cc',
                                },
                            },
                            '& .MuiInputBase-input::placeholder': {
                                color: getSecondaryTextColor(),
                                opacity: 0.7,
                            }
                        }}
                    />

                    {/* Yuborish tugmasi */}
                    <IconButton
                        onClick={handleSend}
                        disabled={!message.trim()}
                        sx={{
                            background: message.trim()
                                ? 'linear-gradient(45deg, #0088cc, #00a2ff)'
                                : (darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'),
                            color: 'white',
                            '&:hover': {
                                background: message.trim()
                                    ? 'linear-gradient(45deg, #0077b3, #0088cc)'
                                    : getHoverBackground(),
                                transform: message.trim() ? 'scale(1.1)' : 'scale(1.05)'
                            },
                            transition: 'all 0.2s ease',
                            width: 48,
                            height: 48
                        }}
                    >
                        <SendIcon
                            sx={{
                                fontSize: 24,
                                color: message.trim() ? 'white' : getSecondaryTextColor(),
                            }}
                        />
                    </IconButton>
                </Box>
            </Box>
        </Paper>
    );
}