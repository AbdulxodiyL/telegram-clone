// components/ChatWindow.jsx
import { Box, Typography, Paper, Avatar } from "@mui/material";
import MessageInput from "./MessageInput";
import { useEffect, useRef, useState } from "react";

export default function ChatWindow({ user, selectedUser, messages, darkMode, onSendMessage }) {
    const messagesEndRef = useRef(null);
    const chatContainerRef = useRef(null);
    const [isNearBottom, setIsNearBottom] = useState(true);
    const [hasNewMessages, setHasNewMessages] = useState(false);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
        setIsNearBottom(true);
        setHasNewMessages(false);
    };

    // Scroll pozitsiyasini kuzatish
    const handleScroll = () => {
        if (chatContainerRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
            const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
            const nearBottom = distanceFromBottom <= 100;
            setIsNearBottom(nearBottom);

            if (!nearBottom && !hasNewMessages) {
                setHasNewMessages(true);
            }
        }
    };

    // Yangi xabar qo'shilganda avtomatik pastga scroll qilish
    useEffect(() => {
        if (isNearBottom) {
            scrollToBottom();
        } else {
            setHasNewMessages(true);
        }
    }, [messages, isNearBottom]);

    // Dark mode uchun ranglar
    const getBackgroundColor = () => {
        return darkMode
            ? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
            : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)';
    };

    const getSurfaceColor = () => {
        return darkMode
            ? 'rgba(30, 30, 30, 0.95)'
            : 'rgba(255, 255, 255, 0.95)';
    };

    const getTextColor = () => {
        return darkMode ? '#ffffff' : '#1a1a1a';
    };

    const getSecondaryTextColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
    };

    const getBorderColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)';
    };

    const getMessageBackground = (isOwn) => {
        if (isOwn) {
            return 'linear-gradient(45deg, #0088cc, #00a2ff)';
        } else {
            return darkMode
                ? 'rgba(255, 255, 255, 0.1)'
                : 'rgba(0, 0, 0, 0.05)';
        }
    };

    const getMessageColor = (isOwn) => {
        return isOwn ? '#ffffff' : getTextColor();
    };

    const formatTime = (timestamp) => {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        return date.toLocaleTimeString('uz-UZ', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        });
    };

    // Xabarlarni sanasi bo'yicha guruhlash
    const groupMessagesByDate = () => {
        const groups = {};
        messages.forEach(message => {
            const date = new Date(message.createdAt).toDateString();
            if (!groups[date]) {
                groups[date] = [];
            }
            groups[date].push(message);
        });
        return groups;
    };

    // Sana formati
    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);

        if (date.toDateString() === today.toDateString()) {
            return "Bugun";
        } else if (date.toDateString() === yesterday.toDateString()) {
            return "Kecha";
        } else {
            return date.toLocaleDateString('uz-UZ', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            });
        }
    };

    const messageGroups = groupMessagesByDate();

    // Yangi xabarlar tugmasi
    const NewMessagesButton = () => (
        <Box
            sx={{
                position: 'absolute',
                bottom: 80,
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 10
            }}
        >
            <Paper
                onClick={scrollToBottom}
                sx={{
                    px: 2,
                    py: 1,
                    borderRadius: 3,
                    background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                    color: 'white',
                    cursor: 'pointer',
                    boxShadow: '0 4px 15px rgba(0, 136, 204, 0.4)',
                    '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 6px 20px rgba(0, 136, 204, 0.6)',
                    },
                    transition: 'all 0.3s ease',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    fontWeight: 600,
                    fontSize: '0.875rem'
                }}
            >
                📩 Yangi xabarlar
            </Paper>
        </Box>
    );

    return (
        <Box
            flex={1}
            display="flex"
            flexDirection="column"
            sx={{
                background: getBackgroundColor(),
                transition: 'all 0.3s ease',
                position: 'relative',
                height: '100%',
                minHeight: 0,
            }}
        >
            <Paper
                ref={chatContainerRef}
                elevation={0}
                onScroll={handleScroll}
                sx={{
                    flex: 1,
                    overflowY: "auto",
                    background: getSurfaceColor(),
                    borderRadius: 0,
                    p: 2,
                    display: 'flex',
                    flexDirection: 'column',
                    border: `1px solid ${getBorderColor()}`,
                    boxShadow: 'none',
                    position: 'relative',
                    minHeight: 0,
                    '&::-webkit-scrollbar': {
                        width: '8px',
                    },
                    '&::-webkit-scrollbar-track': {
                        background: darkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                        borderRadius: '4px',
                    },
                    '&::-webkit-scrollbar-thumb': {
                        background: darkMode ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)',
                        borderRadius: '4px',
                    },
                    '&::-webkit-scrollbar-thumb:hover': {
                        background: darkMode ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)',
                    }
                }}
            >
                {!selectedUser ? (
                    <Box
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                        height="100%"
                        sx={{ minHeight: '200px' }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                color: getSecondaryTextColor(),
                                opacity: 0.7
                            }}
                        >
                            Suhbatni boshlash uchun kontakt tanlang
                        </Typography>
                    </Box>
                ) : messages.length === 0 ? (
                    <Box
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                        height="100%"
                        flexDirection="column"
                        gap={2}
                        sx={{ minHeight: '200px' }}
                    >
                        <Box
                            sx={{
                                width: 80,
                                height: 80,
                                borderRadius: '50%',
                                background: darkMode
                                    ? 'rgba(255, 255, 255, 0.1)'
                                    : 'rgba(0, 136, 204, 0.1)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                            }}
                        >
                            <Typography
                                variant="h4"
                                sx={{
                                    color: getSecondaryTextColor(),
                                    opacity: 0.5
                                }}
                            >
                                💬
                            </Typography>
                        </Box>
                        <Typography
                            variant="h6"
                            sx={{
                                color: getSecondaryTextColor(),
                                opacity: 0.7
                            }}
                        >
                            {selectedUser.username} bilan suhbatni boshlang
                        </Typography>
                        <Typography
                            variant="body2"
                            sx={{
                                color: getSecondaryTextColor(),
                                opacity: 0.5
                            }}
                        >
                            Birinchi xabaringizni yuboring
                        </Typography>
                    </Box>
                ) : (
                    <>
                        <Box sx={{ minHeight: '10px' }} />

                        {Object.entries(messageGroups).map(([date, dayMessages]) => (
                            <Box key={date}>
                                <Box
                                    sx={{
                                        display: 'flex',
                                        justifyContent: 'center',
                                        my: 3
                                    }}
                                >
                                    <Paper
                                        sx={{
                                            px: 2,
                                            py: 1,
                                            borderRadius: 20,
                                            background: darkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                                            color: getSecondaryTextColor(),
                                            fontSize: '0.75rem',
                                            fontWeight: 500
                                        }}
                                    >
                                        {formatDate(dayMessages[0].createdAt)}
                                    </Paper>
                                </Box>

                                {dayMessages.map((message, index) => {
                                    const isOwn = message.senderId === user.id;
                                    const showAvatar = !isOwn && (
                                        index === 0 ||
                                        dayMessages[index - 1].senderId !== message.senderId
                                    );

                                    return (
                                        <Box
                                            key={message.id}
                                            sx={{
                                                display: 'flex',
                                                justifyContent: isOwn ? 'flex-end' : 'flex-start',
                                                alignItems: 'flex-end',
                                                mb: 2,
                                                gap: 1
                                            }}
                                        >
                                            {showAvatar && !isOwn && (
                                                <Avatar
                                                    sx={{
                                                        width: 32,
                                                        height: 32,
                                                        background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                                                        fontSize: '0.8rem',
                                                        fontWeight: 'bold',
                                                        flexShrink: 0
                                                    }}
                                                >
                                                    {selectedUser.username?.charAt(0).toUpperCase()}
                                                </Avatar>
                                            )}

                                            {!showAvatar && !isOwn && <Box sx={{ width: 32 }} />}

                                            <Box
                                                sx={{
                                                    maxWidth: '70%',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    alignItems: isOwn ? 'flex-end' : 'flex-start'
                                                }}
                                            >
                                                <Box
                                                    sx={{
                                                        background: getMessageBackground(isOwn),
                                                        color: getMessageColor(isOwn),
                                                        borderRadius: 3,
                                                        p: 2,
                                                        position: 'relative',
                                                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                                                        border: isOwn ? 'none' : `1px solid ${getBorderColor()}`,
                                                        '&:hover': {
                                                            transform: 'translateY(-1px)',
                                                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                                                        },
                                                        transition: 'all 0.2s ease'
                                                    }}
                                                >
                                                    <Typography
                                                        variant="body1"
                                                        sx={{
                                                            wordBreak: 'break-word',
                                                            lineHeight: 1.4
                                                        }}
                                                    >
                                                        {message.message}
                                                    </Typography>
                                                </Box>

                                                <Typography
                                                    variant="caption"
                                                    sx={{
                                                        mt: 0.5,
                                                        color: getSecondaryTextColor(),
                                                        fontSize: '0.7rem'
                                                    }}
                                                >
                                                    {formatTime(message.createdAt)}
                                                    {isOwn && message.read && (
                                                        <Box component="span" sx={{ ml: 0.5 }}>
                                                            ✓✓
                                                        </Box>
                                                    )}
                                                </Typography>
                                            </Box>

                                            {isOwn && (
                                                <Avatar
                                                    sx={{
                                                        width: 32,
                                                        height: 32,
                                                        background: 'linear-gradient(45deg, #667eea, #764ba2)',
                                                        fontSize: '0.8rem',
                                                        fontWeight: 'bold',
                                                        flexShrink: 0
                                                    }}
                                                >
                                                    {user?.username?.charAt(0).toUpperCase()}
                                                </Avatar>
                                            )}
                                        </Box>
                                    );
                                })}
                            </Box>
                        ))}

                        <Box sx={{ minHeight: '20px' }} />
                        <div ref={messagesEndRef} />
                    </>
                )}

                {(hasNewMessages || !isNearBottom) && <NewMessagesButton />}
            </Paper>

            {selectedUser && (
                <MessageInput
                    onSend={onSendMessage}
                    darkMode={darkMode}
                />
            )}
        </Box>
    );
}