import { useState } from "react";
import {
    Box,
    Typography,
    Card,
    CardContent,
    Switch,
    FormControlLabel,
    Button,
    Divider,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    ListItemSecondaryAction,
    Avatar,
    IconButton,
    Drawer,
    TextField,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Alert
} from "@mui/material";
import {
    ArrowBack,
    Notifications,
    Language,
    Security,
    PrivacyTip,
    Block,
    Delete,
    DarkMode,
    LightMode,
    VolumeUp,
    VolumeOff,
    Email,
    Chat
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useDarkMode } from "../hooks/useDarkMode";

export default function SettingsPage() {
    const navigate = useNavigate();
    const { darkMode, toggleDarkMode } = useDarkMode();
    const [notifications, setNotifications] = useState(() => {
        const saved = localStorage.getItem("notifications");
        return saved ? JSON.parse(saved) : true;
    });
    const [sounds, setSounds] = useState(() => {
        const saved = localStorage.getItem("sounds");
        return saved ? JSON.parse(saved) : true;
    });
    const [emailNotifications, setEmailNotifications] = useState(() => {
        const saved = localStorage.getItem("emailNotifications");
        return saved ? JSON.parse(saved) : false;
    });
    const [language, setLanguage] = useState(() => {
        return localStorage.getItem("language") || "uz";
    });
    const [privacy, setPrivacy] = useState(() => {
        return localStorage.getItem("privacy") || "all";
    });
    const [saveAlert, setSaveAlert] = useState(false);

    const getBackgroundColor = () => {
        return darkMode
            ? 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #2d1b69 100%)'
            : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    };

    const getPaperBackground = () => {
        return darkMode
            ? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
            : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)';
    };

    const getSurfaceColor = () => {
        return darkMode
            ? 'rgba(30, 30, 30, 0.95)'
            : 'rgba(255, 255, 255, 0.95)';
    };

    const getTextColor = () => {
        return darkMode ? '#ffffff' : '#1a1a1a';
    };

    const getSecondaryTextColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
    };

    const getBorderColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)';
    };

    const handleSaveSettings = () => {
        // Save settings to localStorage
        localStorage.setItem("notifications", JSON.stringify(notifications));
        localStorage.setItem("sounds", JSON.stringify(sounds));
        localStorage.setItem("emailNotifications", JSON.stringify(emailNotifications));
        localStorage.setItem("language", language);
        localStorage.setItem("privacy", privacy);

        setSaveAlert(true);
        setTimeout(() => setSaveAlert(false), 3000);
    };

    const handleResetSettings = () => {
        setNotifications(true);
        setSounds(true);
        setEmailNotifications(false);
        setLanguage("uz");
        setPrivacy("all");

        // Dark mode ni reset qilmaslik kerak, chunki u global hook orqali boshqariladi
    };

    const SettingSection = ({ title, children }) => (
        <Card
            sx={{
                mb: 3,
                background: getSurfaceColor(),
                border: `1px solid ${getBorderColor()}`,
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                borderRadius: 3
            }}
        >
            <CardContent sx={{ p: 3 }}>
                <Typography
                    variant="h6"
                    sx={{
                        color: getTextColor(),
                        fontWeight: 700,
                        mb: 2,
                        fontSize: '1.1rem'
                    }}
                >
                    {title}
                </Typography>
                {children}
            </CardContent>
        </Card>
    );

    return (
        <Box
            sx={{
                minHeight: '100vh',
                background: getBackgroundColor(),
                transition: 'background 0.3s ease',
                py: 3
            }}
        >
            {/* Header */}
            <Box sx={{ px: 3, mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                    <IconButton
                        onClick={() => navigate(-1)}
                        sx={{
                            color: getTextColor(),
                            background: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)',
                            '&:hover': {
                                background: darkMode ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)'
                            }
                        }}
                    >
                        <ArrowBack />
                    </IconButton>
                    <Typography
                        variant="h4"
                        sx={{
                            color: getTextColor(),
                            fontWeight: 800,
                            background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                            backgroundClip: 'text',
                            WebkitBackgroundClip: 'text',
                            color: 'transparent'
                        }}
                    >
                        Sozlamalar
                    </Typography>
                </Box>

                {saveAlert && (
                    <Alert
                        severity="success"
                        sx={{
                            mb: 3,
                            borderRadius: 2,
                            background: darkMode ? 'rgba(46, 125, 50, 0.2)' : 'rgba(46, 125, 50, 0.1)',
                            color: getTextColor(),
                            border: `1px solid ${darkMode ? 'rgba(76, 175, 80, 0.3)' : 'rgba(76, 175, 80, 0.2)'}`
                        }}
                    >
                        Sozlamalar muvaffaqiyatli saqlandi!
                    </Alert>
                )}
            </Box>

            {/* Main Content */}
            <Box sx={{ maxWidth: 800, mx: 'auto', px: 3 }}>
                {/* Appearance Settings */}
                <SettingSection title="Ko'rinish">
                    <List sx={{ p: 0 }}>
                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                {darkMode ? (
                                    <DarkMode sx={{ color: '#ffa726', fontSize: 28 }} />
                                ) : (
                                    <LightMode sx={{ color: '#ffa726', fontSize: 28 }} />
                                )}
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Dark Mode
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        {darkMode ? 'Qorongʻu muhit' : 'Yorqin muhit'}
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    checked={darkMode}
                                    onChange={toggleDarkMode}
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                            '&:hover': {
                                                backgroundColor: 'rgba(0, 136, 204, 0.1)',
                                            },
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>
                    </List>
                </SettingSection>

                {/* Notification Settings */}
                <SettingSection title="Bildirishnomalar">
                    <List sx={{ p: 0 }}>
                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <Notifications sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Push bildirishnomalar
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Yangi xabarlar haqida bildirishnoma oling
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    checked={notifications}
                                    onChange={(e) => setNotifications(e.target.checked)}
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>

                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <VolumeUp sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Ovozli bildirishnomalar
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Yangi xabar kelganda ovoz chiqarish
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    checked={sounds}
                                    onChange={(e) => setSounds(e.target.checked)}
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>

                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <Email sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Email bildirishnomalar
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Yangiliklar va yangi xabarlar email orqali
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    checked={emailNotifications}
                                    onChange={(e) => setEmailNotifications(e.target.checked)}
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>
                    </List>
                </SettingSection>

                {/* Language & Region */}
                <SettingSection title="Til va Mintaqa">
                    <FormControl fullWidth sx={{ mb: 2 }}>
                        <InputLabel sx={{ color: getSecondaryTextColor() }}>Til</InputLabel>
                        <Select
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            sx={{
                                color: getTextColor(),
                                '& .MuiOutlinedInput-notchedOutline': {
                                    borderColor: getBorderColor(),
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    borderColor: '#0088cc',
                                },
                                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                                    borderColor: '#0088cc',
                                }
                            }}
                        >
                            <MenuItem value="uz">O'zbekcha</MenuItem>
                            <MenuItem value="ru">Русский</MenuItem>
                            <MenuItem value="en">English</MenuItem>
                        </Select>
                    </FormControl>
                </SettingSection>

                {/* Privacy Settings */}
                <SettingSection title="Maxfiylik">
                    <List sx={{ p: 0 }}>
                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <PrivacyTip sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Profil ko'rinishi
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Kim sizning profilingizni ko'rishi mumkin
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <FormControl sx={{ minWidth: 120 }}>
                                    <Select
                                        value={privacy}
                                        onChange={(e) => setPrivacy(e.target.value)}
                                        sx={{
                                            color: getTextColor(),
                                            '& .MuiOutlinedInput-notchedOutline': {
                                                borderColor: getBorderColor(),
                                            },
                                            '&:hover .MuiOutlinedInput-notchedOutline': {
                                                borderColor: '#0088cc',
                                            }
                                        }}
                                    >
                                        <MenuItem value="all">Hamma</MenuItem>
                                        <MenuItem value="contacts">Kontaktlar</MenuItem>
                                        <MenuItem value="none">Hech kim</MenuItem>
                                    </Select>
                                </FormControl>
                            </ListItemSecondaryAction>
                        </ListItem>

                        <ListItem
                            button
                            sx={{ px: 0, color: '#ef4444' }}
                            onClick={() => {/* Handle block list */ }}
                        >
                            <ListItemIcon>
                                <Block sx={{ color: '#ef4444', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ fontWeight: 600 }}>
                                        Bloklangan foydalanuvchilar
                                    </Typography>
                                }
                            />
                        </ListItem>

                        <ListItem
                            button
                            sx={{ px: 0, color: '#ef4444' }}
                            onClick={() => {/* Handle account deletion */ }}
                        >
                            <ListItemIcon>
                                <Delete sx={{ color: '#ef4444', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ fontWeight: 600 }}>
                                        Hisobni o'chirish
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ fontSize: '0.875rem' }}>
                                        Barcha ma'lumotlar butunlay o'chiriladi
                                    </Typography>
                                }
                            />
                        </ListItem>
                    </List>
                </SettingSection>

                {/* Security Settings */}
                <SettingSection title="Xavfsizlik">
                    <List sx={{ p: 0 }}>
                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <Security sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Ikki faktorli autentifikatsiya
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Hisobingizni qo'shimcha himoya qiling
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>

                        <ListItem
                            button
                            sx={{ px: 0 }}
                            onClick={() => {/* Handle password change */ }}
                        >
                            <ListItemIcon>
                                <Security sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Parolni o'zgartirish
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Yangi parol o'rnating
                                    </Typography>
                                }
                            />
                        </ListItem>
                    </List>
                </SettingSection>

                {/* Chat Settings */}
                <SettingSection title="Chat Sozlamalari">
                    <List sx={{ p: 0 }}>
                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <Chat sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Xabarlarni avto-saqlash
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Barcha xabarlar avtomatik saqlansin
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    defaultChecked
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>

                        <ListItem sx={{ px: 0 }}>
                            <ListItemIcon>
                                <VolumeOff sx={{ color: '#0088cc', fontSize: 28 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={
                                    <Typography sx={{ color: getTextColor(), fontWeight: 600 }}>
                                        Ovozsiz rejim
                                    </Typography>
                                }
                                secondary={
                                    <Typography sx={{ color: getSecondaryTextColor(), fontSize: '0.875rem' }}>
                                        Barcha ovozlarni o'chirib qo'ying
                                    </Typography>
                                }
                            />
                            <ListItemSecondaryAction>
                                <Switch
                                    sx={{
                                        '& .MuiSwitch-switchBase.Mui-checked': {
                                            color: '#0088cc',
                                        },
                                        '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                            backgroundColor: '#0088cc',
                                        },
                                    }}
                                />
                            </ListItemSecondaryAction>
                        </ListItem>
                    </List>
                </SettingSection>

                {/* Action Buttons */}
                <Box sx={{ display: 'flex', gap: 2, mt: 4 }}>
                    <Button
                        variant="outlined"
                        onClick={handleResetSettings}
                        sx={{
                            flex: 1,
                            py: 1.5,
                            borderRadius: 3,
                            textTransform: 'none',
                            fontWeight: 600,
                            borderColor: getBorderColor(),
                            color: getTextColor(),
                            '&:hover': {
                                borderColor: '#0088cc',
                                background: 'rgba(0, 136, 204, 0.1)'
                            }
                        }}
                    >
                        Standart sozlamalar
                    </Button>
                    <Button
                        variant="contained"
                        onClick={handleSaveSettings}
                        sx={{
                            flex: 1,
                            py: 1.5,
                            borderRadius: 3,
                            textTransform: 'none',
                            fontWeight: 600,
                            background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                            '&:hover': {
                                background: 'linear-gradient(45deg, #0077b3, #0088cc)',
                                transform: 'translateY(-1px)',
                                boxShadow: '0 6px 20px rgba(0, 136, 204, 0.4)'
                            },
                            transition: 'all 0.3s ease'
                        }}
                    >
                        Sozlamalarni saqlash
                    </Button>
                </Box>

                {/* App Info */}
                <Box sx={{ mt: 4, textAlign: 'center' }}>
                    <Typography
                        variant="body2"
                        sx={{
                            color: getSecondaryTextColor(),
                            opacity: 0.7
                        }}
                    >
                        Telegram Clone v1.0.0
                    </Typography>
                    <Typography
                        variant="caption"
                        sx={{
                            color: getSecondaryTextColor(),
                            opacity: 0.5
                        }}
                    >
                        © 2024 Barcha huquqlar himoyalangan
                    </Typography>
                </Box>
            </Box>
        </Box>
    );
}