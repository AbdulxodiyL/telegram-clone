import { useState } from "react";
import {
    Box,
    TextField,
    Button,
    Typography,
    Paper,
    InputAdornment,
    IconButton,
    Alert,
    CircularProgress
} from "@mui/material";
import {
    Visibility,
    VisibilityOff,
    Person,
    Email,
    Lock
} from "@mui/icons-material";
import api from "../api";
import { useNavigate } from "react-router-dom";

export default function Register() {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleRegister = async () => {
        if (!username || !email || !password) {
            setError("Iltimos, barcha maydonlarni to'ldiring");
            return;
        }

        setLoading(true);
        setError("");

        try {
            await api.post("/auth/register", { username, email, password });
            alert("Ro'yxatdan o'tish muvaffaqiyatli! Kirish sahifasiga yo'naltiriladi.");
            navigate("/");
        } catch (err) {
            setError(err.response?.data?.error || "Ro'yxatdan o'tishda xato");
        } finally {
            setLoading(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleRegister();
        }
    };

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            height="100vh"
            sx={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                padding: 2
            }}
        >
            <Paper
                elevation={8}
                sx={{
                    p: 4,
                    width: 400,
                    borderRadius: 3,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
                }}
            >
                <Typography
                    variant="h4"
                    align="center"
                    gutterBottom
                    sx={{
                        fontWeight: 'bold',
                        background: 'linear-gradient(45deg, #667eea, #764ba2)',
                        backgroundClip: 'text',
                        WebkitBackgroundClip: 'text',
                        color: 'transparent',
                        mb: 3
                    }}
                >
                    Ro'yxatdan o'tish
                </Typography>

                {error && (
                    <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>
                        {error}
                    </Alert>
                )}

                <TextField
                    label="Foydalanuvchi nomi"
                    fullWidth
                    margin="normal"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Person color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <TextField
                    label="Email"
                    type="email"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Email color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <TextField
                    label="Parol"
                    type={showPassword ? "text" : "password"}
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Lock color="primary" />
                            </InputAdornment>
                        ),
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    onClick={() => setShowPassword(!showPassword)}
                                    edge="end"
                                >
                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                </IconButton>
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    onClick={handleRegister}
                    disabled={loading}
                    startIcon={loading ? <CircularProgress size={20} color="inherit" /> : null}
                    sx={{
                        mt: 3,
                        mb: 2,
                        py: 1.5,
                        borderRadius: 2,
                        background: 'linear-gradient(45deg, #667eea, #764ba2)',
                        fontSize: '1rem',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        boxShadow: '0 4px 15px rgba(102, 126, 234, 0.3)',
                        '&:hover': {
                            boxShadow: '0 6px 20px rgba(102, 126, 234, 0.4)',
                            transform: 'translateY(-1px)',
                        },
                        '&:disabled': {
                            background: 'rgba(102, 126, 234, 0.5)',
                        },
                        transition: 'all 0.3s ease'
                    }}
                >
                    {loading ? "Ro'yxatdan o'tilmoqda..." : "Ro'yxatdan o'tish"}
                </Button>

                <Button
                    fullWidth
                    size="large"
                    onClick={() => navigate("/")}
                    sx={{
                        py: 1,
                        borderRadius: 2,
                        textTransform: 'none',
                        fontSize: '0.9rem',
                        color: '#667eea',
                        border: '1px solid #667eea',
                        '&:hover': {
                            background: 'rgba(102, 126, 234, 0.1)',
                            border: '1px solid #764ba2',
                        },
                        transition: 'all 0.3s ease'
                    }}
                >
                    Hisobingiz bormi? Kirish
                </Button>

                <Typography
                    variant="caption"
                    display="block"
                    align="center"
                    sx={{ mt: 2, color: 'text.secondary' }}
                >
                    Ro'yxatdan o'tish orqali siz shartlarga rozilik bildirasiz
                </Typography>
            </Paper>
        </Box>
    );
}