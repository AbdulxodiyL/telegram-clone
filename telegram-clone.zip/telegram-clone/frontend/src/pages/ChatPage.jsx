import { useEffect, useState, useRef } from "react";
import {
    Box,
    Typography,
    CircularProgress,
    Alert,
    IconButton,
    Menu,
    MenuItem,
    Avatar,
    Divider,
    List,
    ListItem,
    ListItemAvatar,
    ListItemText,
    Badge,
    Button,
    Drawer,
    Switch
} from "@mui/material";
import {
    MoreVert,
    AccountCircle,
    Logout,
    Settings,
    Person,
    FiberManualRecord,
    Groups,
    DarkMode,
    LightMode,
    Close
} from "@mui/icons-material";
import ChatWindow from "../components/ChatWindow";
import socket from "../socket";
import api from "../api";
import { Link, useNavigate } from "react-router-dom";
import { useDarkMode } from "../hooks/useDarkMode";

export default function ChatPage() {
    const [user, setUser] = useState(null);
    const [users, setUsers] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const [messages, setMessages] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [anchorEl, setAnchorEl] = useState(null);
    const [profileDrawerOpen, setProfileDrawerOpen] = useState(false);
    const { darkMode, toggleDarkMode } = useDarkMode();
    const navigate = useNavigate();
    const messagesEndRef = useRef(null);
    const [tempMessage, setTempMessage] = useState('');

    // Xabarlarni pastga scroll qilish
    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    // Ma'lumotlarni yuklash
    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) navigate("/");

        const fetchData = async () => {
            try {
                setLoading(true);
                const profile = await api.get("/auth/profile", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUser(profile.data.user);

                const res = await api.get("/auth/users");
                setUsers(res.data.users.filter(u => u.id !== profile.data.user.id));
            } catch (err) {
                setError("Ma'lumotlarni yuklashda xato");
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [navigate]);

    // Socket connectionni boshqarish - YANGILANDI
    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token && user) {
            socket.auth = { token };
            socket.connect();

            // Foydalanuvchini serverga ro'yxatdan o'tkazish
            socket.emit('registerUser', user.id);

            socket.on("connect", () => {
                console.log("✅ Socket ulandi:", socket.id);
            });

            socket.on("disconnect", () => {
                console.log("🔴 Socket uzildi");
            });

            socket.on("connect_error", (error) => {
                console.error("❌ Socket connection error:", error);
            });

            return () => {
                socket.off("connect");
                socket.off("disconnect");
                socket.off("connect_error");
                socket.disconnect();
            };
        }
    }, [user]);

    // Xabarlarni yuklash - YANGILANDI
    useEffect(() => {
        if (!user) return;

        const token = localStorage.getItem("token");
        if (!token) return;

        const loadMessages = async () => {
            if (!selectedUser) return;
            try {
                const response = await api.get(`/chat/conversation/${user.id}/${selectedUser.id}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setMessages(response?.data?.messages || []);
            } catch (error) {
                if (error.response?.status === 404) {
                    console.warn("🟠 Yangi endpoint topilmadi, eski usulga o‘tyapmiz");
                    const response = await api.get(`/chat`, {
                        headers: { Authorization: `Bearer ${token}` },
                    });
                    const filteredMessages = response.data.chats.filter(chat =>
                        (chat.senderId === user.id && chat.receiverId === selectedUser.id) ||
                        (chat.receiverId === user.id && chat.senderId === selectedUser.id)
                    );
                    setMessages(filteredMessages);
                } else {
                    console.error("❌ Xabarlarni yuklashda xato:", error);
                }
            }
        };


        // Xabarlarni yuklash
        loadMessages();

    }, [user, selectedUser]); // Bu faqat xabarlarni yuklash uchun

    // 🔻 Socket listener alohida useEffect
    // 🔻 Socket listener alohida useEffect
    useEffect(() => {
        if (!socket || !user) return;

        // 🔹 Eski listenerlarni tozalash
        socket.off("receiveMessage");

        const handleReceiveMessage = (newMessage) => {
            if (
                selectedUser &&
                ((newMessage.senderId === user.id && newMessage.receiverId === selectedUser.id) ||
                    (newMessage.receiverId === user.id && newMessage.senderId === selectedUser.id))
            ) {
                setMessages(prev => {
                    const exists = prev.some(
                        msg => msg.id === newMessage.id || (msg.tempId && msg.tempId === newMessage.tempId)
                    );
                    if (exists) return prev;
                    return [...prev, newMessage];
                });
            }
        };

        // 🔹 Listenerni ulang
        socket.on("receiveMessage", handleReceiveMessage);

        // 🔹 Tozalash (component unmount yoki chat o‘zgarsa)
        return () => {
            socket.off("receiveMessage", handleReceiveMessage);
        };
    }, [selectedUser, user]);




    const handleMenuOpen = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleProfile = () => {
        handleMenuClose();
        setProfileDrawerOpen(true);
    };

    const handleUserProfile = () => {
        if (selectedUser) {
            navigate(`/user/${selectedUser.id}`);
        }
    };

    const handleLogout = () => {
        handleMenuClose();
        localStorage.removeItem("token");
        socket.disconnect();
        navigate("/");
    };

    // Xabar yuborish funksiyasi - YANGILANDI
    const sendMessage = async (message) => {
        if (!message.trim() || !selectedUser || !user) return;

        const messageData = {
            message: message.trim(),
            senderId: user.id,
            receiverId: selectedUser.id
        };

        try {
            // Optimistic update - darrov xabarni ko'rsatish
            const tempMessage = {
                ...messageData,
                id: Date.now(), // Vaqtinchalik ID
                tempId: Date.now(), // Optimistic update uchun alohida ID
                createdAt: new Date().toISOString(),
                read: false,
                status: 'sending'
            };

            setMessages(prev => [...prev, tempMessage]);

            // 1. Socket orqali real-time xabar yuborish
            socket.emit("sendMessage", messageData);

            // 2. Backendga ham yuborish (agar kerak bo'lsa)
            const token = localStorage.getItem("token");
            const response = await api.post("/chat", messageData, {
                headers: { Authorization: `Bearer ${token}` },
            });

            // Agar backenddan javob kelsa, optimistic messageni yangilash
            if (response.data.chat) {
                setMessages(prev =>
                    prev.map(msg =>
                        msg.tempId === tempMessage.tempId
                            ? { ...response.data.chat, status: 'sent' }
                            : msg
                    )
                );
            }

        } catch (error) {
            console.error("❌ Xabar yuborishda xato:", error);
            // Optimistic update ni bekor qilish yoki xatolik holatini ko'rsatish
            setMessages(prev =>
                prev.map(msg =>
                    msg.tempId === tempMessage.tempId
                        ? { ...msg, status: 'error' }
                        : msg
                )
            );
            setError("Xabar yuborish muvaffaqiyatsiz");
        }
    };

    const getBackgroundColor = () => {
        return darkMode
            ? 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #2d1b69 100%)'
            : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    };

    const getPaperBackground = () => {
        return darkMode
            ? 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)'
            : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)';
    };

    const getSurfaceColor = () => {
        return darkMode
            ? 'rgba(30, 30, 30, 0.95)'
            : 'rgba(255, 255, 255, 0.95)';
    };

    const getTextColor = () => {
        return darkMode ? '#ffffff' : '#1a1a1a';
    };

    const getSecondaryTextColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';
    };

    const getBorderColor = () => {
        return darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)';
    };

    // Sidebar komponenti
    const Sidebar = ({ users, onSelectUser, selectedUser }) => (
        <Box sx={{ flex: 1, overflow: 'auto' }}>
            <Box sx={{ p: 2, pb: 1 }}>
                <Typography
                    variant="h6"
                    sx={{
                        color: getTextColor(),
                        fontWeight: 700,
                        fontSize: '1.2rem',
                        mb: 1
                    }}
                >
                    Kontaktlar
                </Typography>
                <Typography
                    variant="body2"
                    sx={{
                        color: getSecondaryTextColor(),
                        mb: 2
                    }}
                >
                    {users.length} ta foydalanuvchi
                </Typography>
            </Box>

            <List sx={{ p: 0 }}>
                {users.map((contact) => (
                    <ListItem
                        key={contact.id}
                        button
                        selected={selectedUser?.id === contact.id}
                        onClick={() => onSelectUser(contact)}
                        sx={{
                            px: 2,
                            py: 1.5,
                            borderBottom: '1px solid',
                            borderColor: getBorderColor(),
                            '&:hover': {
                                background: darkMode
                                    ? 'linear-gradient(45deg, rgba(0, 136, 204, 0.2), rgba(0, 162, 255, 0.2))'
                                    : 'linear-gradient(45deg, rgba(0, 136, 204, 0.1), rgba(0, 162, 255, 0.1))',
                                transform: 'translateX(4px)',
                            },
                            '&.Mui-selected': {
                                background: 'linear-gradient(45deg, rgba(0, 136, 204, 0.25), rgba(0, 162, 255, 0.25))',
                                borderRight: '3px solid #0088cc',
                                '&:hover': {
                                    background: 'linear-gradient(45deg, rgba(0, 136, 204, 0.3), rgba(0, 162, 255, 0.3))',
                                }
                            },
                            transition: 'all 0.3s ease',
                            color: getTextColor(),
                            backdropFilter: 'blur(10px)'
                        }}
                    >
                        <ListItemAvatar>
                            <Badge
                                overlap="circular"
                                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                variant="dot"
                                sx={{
                                    '& .MuiBadge-dot': {
                                        backgroundColor: '#4ade80',
                                        width: 12,
                                        height: 12,
                                        borderRadius: '50%',
                                        border: `2px solid ${darkMode ? '#1a1a1a' : 'white'}`
                                    }
                                }}
                            >
                                <Avatar
                                    sx={{
                                        width: 48,
                                        height: 48,
                                        background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                                        fontWeight: 'bold',
                                        fontSize: '1.2rem',
                                        boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)'
                                    }}
                                >
                                    {contact.username?.charAt(0).toUpperCase()}
                                </Avatar>
                            </Badge>
                        </ListItemAvatar>

                        <ListItemText
                            primary={
                                <Typography
                                    variant="body1"
                                    sx={{
                                        fontWeight: 600,
                                        color: getTextColor()
                                    }}
                                >
                                    {contact.username}
                                </Typography>
                            }
                            secondary={
                                <Typography
                                    variant="caption"
                                    sx={{
                                        color: getSecondaryTextColor(),
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 0.5
                                    }}
                                >
                                    <FiberManualRecord sx={{ fontSize: 10 }} />
                                    Online
                                </Typography>
                            }
                        />
                    </ListItem>
                ))}
            </List>

            {users.length === 0 && (
                <Box
                    textAlign="center"
                    sx={{
                        p: 4,
                        color: getSecondaryTextColor()
                    }}
                >
                    <Groups sx={{ fontSize: 48, mb: 2, opacity: 0.5 }} />
                    <Typography variant="body1">
                        Hozircha kontaktlar mavjud emas
                    </Typography>
                </Box>
            )}
        </Box>
    );

    // Profile Drawer komponenti
    const ProfileDrawer = () => (
        <Drawer
            anchor="right"
            open={profileDrawerOpen}
            onClose={() => setProfileDrawerOpen(false)}
            sx={{
                '& .MuiDrawer-paper': {
                    width: 360,
                    background: getPaperBackground(),
                    color: getTextColor(),
                    borderLeft: `1px solid ${getBorderColor()}`,
                    boxShadow: darkMode
                        ? '-8px 0 30px rgba(0, 0, 0, 0.5)'
                        : '-8px 0 30px rgba(0, 0, 0, 0.1)'
                },
            }}
        >
            <Box sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
                {/* Header */}
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
                    <Typography variant="h5" sx={{ fontWeight: 700 }}>
                        Profil
                    </Typography>
                    <IconButton
                        onClick={() => setProfileDrawerOpen(false)}
                        sx={{
                            color: getTextColor(),
                            background: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)',
                            '&:hover': {
                                background: darkMode ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)'
                            }
                        }}
                    >
                        <Close />
                    </IconButton>
                </Box>

                {/* User Info */}
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                    <Avatar
                        sx={{
                            width: 100,
                            height: 100,
                            background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                            fontWeight: 'bold',
                            fontSize: '2.5rem',
                            margin: '0 auto 16px',
                            boxShadow: '0 8px 25px rgba(0, 0, 0, 0.3)'
                        }}
                    >
                        {user?.username?.charAt(0).toUpperCase()}
                    </Avatar>
                    <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
                        {user?.username}
                    </Typography>
                    <Typography variant="body2" sx={{ color: getSecondaryTextColor(), mb: 2 }}>
                        {user?.email}
                    </Typography>
                    <Box
                        sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 1,
                            padding: '4px 12px',
                            borderRadius: 20,
                            background: darkMode ? 'rgba(74, 222, 128, 0.2)' : 'rgba(74, 222, 128, 0.15)',
                            color: '#4ade80',
                            border: `1px solid ${darkMode ? 'rgba(74, 222, 128, 0.3)' : 'rgba(74, 222, 128, 0.2)'}`
                        }}
                    >
                        <FiberManualRecord sx={{ fontSize: 12 }} />
                        <Typography variant="caption" sx={{ fontWeight: 600 }}>
                            Online
                        </Typography>
                    </Box>
                </Box>

                <Divider sx={{ my: 3, borderColor: getBorderColor() }} />

                {/* Dark Mode Toggle */}
                <Box sx={{ mb: 3 }}>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                        Sozlamalar
                    </Typography>
                    <Box
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            p: 2,
                            borderRadius: 2,
                            background: darkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.03)',
                            border: `1px solid ${getBorderColor()}`,
                            transition: 'all 0.3s ease',
                            '&:hover': {
                                background: darkMode ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)',
                                transform: 'translateY(-1px)',
                                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                            }
                        }}
                    >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                            {darkMode ? (
                                <DarkMode sx={{ color: '#ffa726', fontSize: 28 }} />
                            ) : (
                                <LightMode sx={{ color: '#ffa726', fontSize: 28 }} />
                            )}
                            <Box>
                                <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                    Dark Mode
                                </Typography>
                                <Typography variant="caption" sx={{ color: getSecondaryTextColor() }}>
                                    {darkMode ? 'Qorongʻu muhit' : 'Yorqin muhit'}
                                </Typography>
                            </Box>
                        </Box>
                        <Switch
                            checked={darkMode}
                            onChange={toggleDarkMode}
                            sx={{
                                '& .MuiSwitch-switchBase.Mui-checked': {
                                    color: '#0088cc',
                                    '&:hover': {
                                        backgroundColor: 'rgba(0, 136, 204, 0.1)',
                                    },
                                },
                                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                    backgroundColor: '#0088cc',
                                },
                            }}
                        />
                    </Box>
                </Box>

                {/* Actions */}
                <Box sx={{ mb: 3, flex: 1 }}>
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                        Harakatlar
                    </Typography>
                    <Link to="/settings" style={{ textDecoration: 'none' }}>
                        <Button
                            fullWidth
                            startIcon={<Settings />}
                            sx={{
                                justifyContent: 'flex-start',
                                padding: '12px 16px',
                                borderRadius: 2,
                                mb: 1,
                                background: darkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.03)',
                                color: getTextColor(),
                                border: `1px solid ${getBorderColor()}`,
                                '&:hover': {
                                    background: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)',
                                    transform: 'translateY(-1px)',
                                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                                },
                                transition: 'all 0.3s ease'
                            }}
                        >
                            Sozlamalar
                        </Button>
                    </Link>

                    <Button
                        fullWidth
                        startIcon={<AccountCircle />}
                        sx={{
                            justifyContent: 'flex-start',
                            padding: '12px 16px',
                            borderRadius: 2,
                            mb: 1,
                            background: darkMode ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.03)',
                            color: getTextColor(),
                            border: `1px solid ${getBorderColor()}`,
                            '&:hover': {
                                background: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)',
                                transform: 'translateY(-1px)',
                                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                            },
                            transition: 'all 0.3s ease'
                        }}
                    >
                        Profilni tahrirlash
                    </Button>
                </Box>

                {/* Logout Button */}
                <Button
                    fullWidth
                    startIcon={<Logout />}
                    onClick={handleLogout}
                    sx={{
                        justifyContent: 'flex-start',
                        padding: '12px 16px',
                        borderRadius: 2,
                        background: 'rgba(239, 68, 68, 0.1)',
                        color: '#ef4444',
                        border: '1px solid rgba(239, 68, 68, 0.2)',
                        '&:hover': {
                            background: 'rgba(239, 68, 68, 0.2)',
                            transform: 'translateY(-1px)',
                            boxShadow: '0 4px 12px rgba(239, 68, 68, 0.2)'
                        },
                        transition: 'all 0.3s ease'
                    }}
                >
                    Chiqish
                </Button>
            </Box>
        </Drawer>
    );

    if (loading) {
        return (
            <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                height="100vh"
                sx={{
                    background: getBackgroundColor(),
                    transition: 'background 0.3s ease'
                }}
            >
                <Box
                    textAlign="center"
                    sx={{
                        background: getSurfaceColor(),
                        padding: 6,
                        borderRadius: 4,
                        boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
                        backdropFilter: 'blur(20px)',
                        border: `1px solid ${getBorderColor()}`
                    }}
                >
                    <CircularProgress
                        size={70}
                        sx={{
                            color: '#0088cc',
                            mb: 3
                        }}
                    />
                    <Typography
                        variant="h5"
                        sx={{
                            color: getTextColor(),
                            fontWeight: 600,
                            mb: 1
                        }}
                    >
                        Yuklanmoqda...
                    </Typography>
                    <Typography
                        variant="body2"
                        sx={{
                            color: getSecondaryTextColor()
                        }}
                    >
                        Ma'lumotlar yuklanmoqda
                    </Typography>
                </Box>
            </Box>
        );
    }

    if (error) {
        return (
            <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                height="100vh"
                sx={{
                    background: getBackgroundColor(),
                    transition: 'background 0.3s ease'
                }}
            >
                <Alert
                    severity="error"
                    sx={{
                        borderRadius: 3,
                        fontSize: '1.1rem',
                        padding: 3,
                        maxWidth: 400,
                        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
                        background: getSurfaceColor(),
                        color: getTextColor(),
                        '& .MuiAlert-icon': {
                            color: '#ef4444'
                        }
                    }}
                >
                    {error}
                </Alert>
            </Box>
        );
    }

    return (
        <Box
            display="flex"
            height="100vh"
            sx={{
                background: getBackgroundColor(),
                overflow: 'hidden',
                transition: 'background 0.3s ease'
            }}
        >
            {/* Sidebar */}
            <Box
                sx={{
                    width: 380,
                    background: getPaperBackground(),
                    backdropFilter: 'blur(20px)',
                    borderRight: `1px solid ${getBorderColor()}`,
                    boxShadow: darkMode
                        ? '8px 0 30px rgba(0, 0, 0, 0.4)'
                        : '8px 0 30px rgba(0, 0, 0, 0.1)',
                    display: 'flex',
                    flexDirection: 'column',
                    position: 'relative',
                    transition: 'all 0.3s ease'
                }}
            >
                {/* User Profile Header */}
                <Box
                    sx={{
                        padding: '16px 20px',
                        background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        boxShadow: '0 2px 15px rgba(0, 136, 204, 0.4)',
                        position: 'relative',
                        overflow: 'hidden',
                        '&::before': {
                            content: '""',
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            background: 'linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0))',
                            pointerEvents: 'none'
                        }
                    }}
                >
                    <Box display="flex" alignItems="center" gap={2} sx={{ flex: 1, position: 'relative', zIndex: 1 }}>
                        <Avatar
                            sx={{
                                width: 48,
                                height: 48,
                                background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                                fontWeight: 'bold',
                                fontSize: '1.3rem',
                                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.3)',
                                cursor: 'pointer',
                                '&:hover': {
                                    transform: 'scale(1.05)',
                                    transition: 'transform 0.2s ease'
                                }
                            }}
                            onClick={handleProfile}
                        >
                            {user?.username?.charAt(0).toUpperCase()}
                        </Avatar>
                        <Box sx={{ flex: 1 }}>
                            <Typography
                                variant="h6"
                                sx={{
                                    fontWeight: 700,
                                    fontSize: '1.1rem'
                                }}
                            >
                                {user?.username}
                            </Typography>
                            <Typography
                                variant="caption"
                                sx={{
                                    opacity: 0.9,
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 0.5
                                }}
                            >
                                <Box
                                    sx={{
                                        width: 8,
                                        height: 8,
                                        borderRadius: '50%',
                                        background: '#4ade80',
                                    }}
                                />
                                Online
                            </Typography>
                        </Box>
                    </Box>

                    <IconButton
                        sx={{
                            color: 'white',
                            background: 'rgba(255, 255, 255, 0.2)',
                            '&:hover': {
                                background: 'rgba(255, 255, 255, 0.3)',
                                transform: 'scale(1.1)'
                            },
                            transition: 'all 0.2s ease',
                            position: 'relative',
                            zIndex: 1
                        }}
                        onClick={handleMenuOpen}
                    >
                        <MoreVert />
                    </IconButton>

                    <Menu
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={handleMenuClose}
                        PaperProps={{
                            sx: {
                                mt: 1,
                                borderRadius: 3,
                                boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3)',
                                minWidth: 180,
                                background: getSurfaceColor(),
                                backdropFilter: 'blur(20px)',
                                color: getTextColor(),
                                border: `1px solid ${getBorderColor()}`
                            }
                        }}
                    >
                        <MenuItem onClick={handleProfile}>
                            <AccountCircle sx={{ mr: 2 }} />
                            Mening profilim
                        </MenuItem>
                        <MenuItem onClick={handleLogout} sx={{ color: '#ff6b6b' }}>
                            <Logout sx={{ mr: 2 }} />
                            Chiqish
                        </MenuItem>
                    </Menu>
                </Box>

                {/* Contacts List */}
                <Sidebar
                    users={users}
                    onSelectUser={setSelectedUser}
                    selectedUser={selectedUser}
                />
            </Box>

            {/* Chat Window */}
            <Box sx={{
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                background: getSurfaceColor(),
                backdropFilter: 'blur(10px)',
                color: getTextColor(),
                transition: 'all 0.3s ease'
            }}>
                {selectedUser ? (
                    <>
                        {/* Chat Header with Profile Button */}
                        <Box sx={{
                            p: 2,
                            borderBottom: `1px solid ${getBorderColor()}`,
                            background: getSurfaceColor(),
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
                            backdropFilter: 'blur(10px)'
                        }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                <Avatar
                                    sx={{
                                        width: 45,
                                        height: 45,
                                        background: 'linear-gradient(45deg, #ff6b6b, #ffa726)',
                                        fontWeight: 'bold',
                                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)'
                                    }}
                                >
                                    {selectedUser?.username?.charAt(0).toUpperCase()}
                                </Avatar>
                                <Box>
                                    <Typography variant="h6" sx={{ fontWeight: 600, color: getTextColor() }}>
                                        {selectedUser?.username}
                                    </Typography>
                                    <Typography variant="caption" sx={{ color: getSecondaryTextColor() }}>
                                        Online - Suhbat qilish
                                    </Typography>
                                </Box>
                            </Box>

                            {/* Profile Button */}
                            <Button
                                variant="outlined"
                                startIcon={<Person />}
                                onClick={handleUserProfile}
                                sx={{
                                    borderRadius: 3,
                                    textTransform: 'none',
                                    fontWeight: 600,
                                    borderColor: '#0088cc',
                                    color: '#0088cc',
                                    background: 'rgba(0, 136, 204, 0.1)',
                                    '&:hover': {
                                        background: 'rgba(0, 136, 204, 0.2)',
                                        borderColor: '#0077b3',
                                        transform: 'translateY(-1px)',
                                        boxShadow: '0 4px 12px rgba(0, 136, 204, 0.3)'
                                    },
                                    transition: 'all 0.3s ease'
                                }}
                            >
                                Profilni ko'rish
                            </Button>
                        </Box>

                        {/* Chat Window */}
                        <ChatWindow
                            user={user}
                            selectedUser={selectedUser}
                            messages={messages}
                            setMessages={setMessages}
                            darkMode={darkMode}
                            socket={socket}
                            onSendMessage={sendMessage}
                            messagesEndRef={messagesEndRef}
                        />
                    </>
                ) : (
                    <Box
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                        height="100%"
                        sx={{
                            background: getSurfaceColor(),
                        }}
                    >
                        <Box
                            textAlign="center"
                            sx={{
                                background: getSurfaceColor(),
                                padding: 4,
                                borderRadius: 3,
                                boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)',
                                maxWidth: 400,
                                border: `1px solid ${getBorderColor()}`
                            }}
                        >
                            <Box
                                sx={{
                                    width: 80,
                                    height: 80,
                                    borderRadius: '50%',
                                    background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    margin: '0 auto 20px',
                                    boxShadow: '0 8px 25px rgba(0, 136, 204, 0.4)'
                                }}
                            >
                                <Person sx={{ fontSize: 40, color: 'white' }} />
                            </Box>

                            <Typography
                                variant="h5"
                                sx={{
                                    color: getTextColor(),
                                    mb: 2,
                                    fontWeight: 600
                                }}
                            >
                                Telegram Clone
                            </Typography>

                            <Typography
                                variant="body2"
                                sx={{
                                    color: getSecondaryTextColor(),
                                    mb: 3
                                }}
                            >
                                Suhbatni boshlash uchun chap tomondan kontakt tanlang
                            </Typography>

                            <Button
                                variant="contained"
                                startIcon={<AccountCircle />}
                                onClick={handleProfile}
                                sx={{
                                    borderRadius: 3,
                                    textTransform: 'none',
                                    fontWeight: 600,
                                    background: 'linear-gradient(45deg, #667eea, #764ba2)',
                                    '&:hover': {
                                        background: 'linear-gradient(45deg, #5a6fd8, #6a42a0)',
                                        transform: 'translateY(-2px)',
                                        boxShadow: '0 6px 20px rgba(102, 126, 234, 0.4)'
                                    },
                                    transition: 'all 0.3s ease'
                                }}
                            >
                                Mening profilim
                            </Button>
                        </Box>
                    </Box>
                )}
            </Box>

            {/* Profile Drawer */}
            <ProfileDrawer />
        </Box>
    );
}