import { useEffect, useState } from "react";
import {
    Box,
    TextField,
    Button,
    Typography,
    Avatar,
    Paper,
    IconButton,
    InputAdornment,
    Alert,
    CircularProgress,
    Divider
} from "@mui/material";
import {
    Edit,
    CameraAlt,
    Email,
    Person,
    Description,
    Logout,
    Save,
    ArrowBack
} from "@mui/icons-material";
import api from "../api";
import { useNavigate } from "react-router-dom";

export default function Profile() {
    const [user, setUser] = useState(null);
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [bio, setBio] = useState("");
    const [avatar, setAvatar] = useState("");
    const [avatarFile, setAvatarFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const token = localStorage.getItem("token");
    if (!token) navigate("/");

    // 🔹 Profilni olish
    useEffect(() => {
        const fetchProfile = async () => {
            try {
                setLoading(true);
                const res = await api.get("/auth/profile", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                const user = res.data.user;
                setUser(user);
                setUsername(user.username);
                setEmail(user.email);
                setBio(user.bio || "");
                if (user.avatar) {
                    setAvatar(`http://localhost:5000${user.avatar}`);
                }
            } catch (err) {
                setError("Profilni olishda xato");
            } finally {
                setLoading(false);
            }
        };
        fetchProfile();
    }, [token, navigate]);

    // 🔹 Profilni yangilash
    const handleUpdate = async () => {
        try {
            setLoading(true);
            setError("");
            setSuccess("");

            const formData = new FormData();
            formData.append("username", username);
            formData.append("email", email);
            formData.append("bio", bio);
            if (avatarFile) formData.append("avatar", avatarFile);

            const res = await api.put("/auth/edit", formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "multipart/form-data",
                },
            });

            setSuccess("Profil muvaffaqiyatli yangilandi ✅");

            const updatedUser = res.data.user;
            if (updatedUser.avatar) {
                setAvatar(`http://localhost:5000${updatedUser.avatar}`);
            }
        } catch (err) {
            setError(err.response?.data?.error || "Yangilashda xato ❌");
        } finally {
            setLoading(false);
        }
    };

    // 🔹 Chiqish
    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/");
    };

    const handleBack = () => {
        navigate("/chat");
    };

    if (!user && loading) {
        return (
            <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                height="100vh"
                sx={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                }}
            >
                <CircularProgress size={60} sx={{ color: 'white' }} />
            </Box>
        );
    }

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="100vh"
            sx={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                py: 4,
                px: 2
            }}
        >
            <Paper
                elevation={8}
                sx={{
                    p: 4,
                    width: 450,
                    borderRadius: 4,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(20px)',
                    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.2)',
                    border: '1px solid rgba(255, 255, 255, 0.3)'
                }}
            >
                <Box display="flex" alignItems="center" justifyContent="space-between" mb={3}>
                    <IconButton
                        onClick={handleBack}
                        sx={{
                            background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                            color: 'white',
                            '&:hover': {
                                background: 'linear-gradient(45deg, #0077b3, #0099e6)',
                                transform: 'translateX(-2px)'
                            },
                            transition: 'all 0.3s ease'
                        }}
                    >
                        <ArrowBack />
                    </IconButton>

                    <Typography
                        variant="h4"
                        align="center"
                        sx={{
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #667eea, #764ba2)',
                            backgroundClip: 'text',
                            WebkitBackgroundClip: 'text',
                            color: 'transparent',
                            flex: 1
                        }}
                    >
                        Profil
                    </Typography>
                </Box>

                {success && (
                    <Alert
                        severity="success"
                        sx={{
                            mb: 3,
                            borderRadius: 3,
                            background: 'linear-gradient(45deg, #4ade80, #22c55e)',
                            color: 'white',
                            fontWeight: 600
                        }}
                    >
                        {success}
                    </Alert>
                )}
                {error && (
                    <Alert
                        severity="error"
                        sx={{
                            mb: 3,
                            borderRadius: 3
                        }}
                    >
                        {error}
                    </Alert>
                )}

                <Box display="flex" flexDirection="column" alignItems="center" mb={4}>
                    <Box sx={{ position: 'relative' }}>
                        <Avatar
                            src={avatar}
                            sx={{
                                width: 120,
                                height: 120,
                                border: '4px solid',
                                borderColor: 'primary.main',
                                boxShadow: '0 8px 25px rgba(0, 0, 0, 0.2)'
                            }}
                        />
                        <IconButton
                            component="label"
                            sx={{
                                position: 'absolute',
                                bottom: 0,
                                right: 0,
                                background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                                color: 'white',
                                '&:hover': {
                                    background: 'linear-gradient(45deg, #0077b3, #0099e6)',
                                    transform: 'scale(1.1)'
                                },
                                transition: 'all 0.3s ease'
                            }}
                        >
                            <CameraAlt />
                            <input
                                type="file"
                                hidden
                                accept="image/*"
                                onChange={(e) => {
                                    const file = e.target.files[0];
                                    setAvatarFile(file);
                                    setAvatar(URL.createObjectURL(file));
                                }}
                            />
                        </IconButton>
                    </Box>
                    <Typography
                        variant="h6"
                        sx={{
                            mt: 2,
                            fontWeight: 600,
                            color: 'text.primary'
                        }}
                    >
                        {user?.username}
                    </Typography>
                    <Typography
                        variant="body2"
                        sx={{
                            color: 'text.secondary'
                        }}
                    >
                        Profil rasmingizni yangilang
                    </Typography>
                </Box>

                <TextField
                    label="Foydalanuvchi nomi"
                    fullWidth
                    margin="normal"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Person color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 3,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <TextField
                    label="Email"
                    type="email"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Email color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 3,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <TextField
                    label="Bio"
                    multiline
                    rows={3}
                    fullWidth
                    margin="normal"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="O'zingiz haqingizda qisqacha ma'lumot..."
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Description color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 3,
                            '&:hover fieldset': {
                                borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#764ba2',
                            },
                        }
                    }}
                />

                <Divider sx={{ my: 3 }} />

                <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    onClick={handleUpdate}
                    disabled={loading}
                    startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <Save />}
                    sx={{
                        py: 1.5,
                        borderRadius: 3,
                        background: 'linear-gradient(45deg, #667eea, #764ba2)',
                        fontSize: '1rem',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        boxShadow: '0 6px 20px rgba(102, 126, 234, 0.4)',
                        '&:hover': {
                            boxShadow: '0 8px 25px rgba(102, 126, 234, 0.6)',
                            transform: 'translateY(-2px)',
                        },
                        '&:disabled': {
                            background: 'rgba(102, 126, 234, 0.5)',
                        },
                        transition: 'all 0.3s ease',
                        mb: 2
                    }}
                >
                    {loading ? "Yangilanmoqda..." : "Profilni yangilash"}
                </Button>

                <Button
                    variant="outlined"
                    fullWidth
                    size="large"
                    onClick={handleLogout}
                    startIcon={<Logout />}
                    sx={{
                        py: 1.5,
                        borderRadius: 3,
                        borderColor: '#ff6b6b',
                        color: '#ff6b6b',
                        textTransform: 'none',
                        fontSize: '1rem',
                        fontWeight: 'bold',
                        '&:hover': {
                            background: '#ff6b6b',
                            color: 'white',
                            borderColor: '#ff6b6b',
                            transform: 'translateY(-1px)',
                            boxShadow: '0 4px 15px rgba(255, 107, 107, 0.4)'
                        },
                        transition: 'all 0.3s ease'
                    }}
                >
                    Hisobdan chiqish
                </Button>

                <Box
                    sx={{
                        mt: 3,
                        p: 2,
                        background: 'linear-gradient(45deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1))',
                        borderRadius: 3,
                        textAlign: 'center'
                    }}
                >
                    <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                        Profil yangilandi: {new Date().toLocaleDateString()}
                    </Typography>
                </Box>
            </Paper>
        </Box>
    );
}