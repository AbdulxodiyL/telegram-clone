import { useState } from "react";
import {
    Box,
    TextField,
    Button,
    Typography,
    Paper,
    InputAdornment,
    IconButton,
    Alert,
    CircularProgress
} from "@mui/material";
import {
    Visibility,
    VisibilityOff,
    Email,
    Lock,
    Telegram
} from "@mui/icons-material";
import api from "../api";
import { useNavigate } from "react-router-dom";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleLogin = async () => {
        if (!email || !password) {
            setError("Iltimos, email va parolni kiriting");
            return;
        }

        setLoading(true);
        setError("");

        try {
            const res = await api.post("/auth/login", { email, password });
            localStorage.setItem("token", res.data.token);
            navigate("/chat");
        } catch (err) {
            setError(err.response?.data?.error || "Login xatosi");
        } finally {
            setLoading(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleLogin();
        }
    };

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            height="100vh"
            sx={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                padding: 2
            }}
        >
            <Paper
                elevation={8}
                sx={{
                    p: 4,
                    width: 400,
                    borderRadius: 3,
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
                }}
            >
                <Box display="flex" alignItems="center" justifyContent="center" mb={2}>
                    <Telegram
                        sx={{
                            fontSize: 40,
                            color: '#0088cc',
                            mr: 1
                        }}
                    />
                    <Typography
                        variant="h4"
                        align="center"
                        sx={{
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                            backgroundClip: 'text',
                            WebkitBackgroundClip: 'text',
                            color: 'transparent'
                        }}
                    >
                        Telegram Clone
                    </Typography>
                </Box>

                <Typography
                    variant="h5"
                    align="center"
                    gutterBottom
                    sx={{
                        fontWeight: 600,
                        color: '#333',
                        mb: 3
                    }}
                >
                    Tizimga kirish
                </Typography>

                {error && (
                    <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>
                        {error}
                    </Alert>
                )}

                <TextField
                    label="Email"
                    type="email"
                    fullWidth
                    margin="normal"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Email color="primary" />
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover fieldset': {
                                borderColor: '#0088cc',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#0088cc',
                            },
                        }
                    }}
                />

                <TextField
                    label="Parol"
                    type={showPassword ? "text" : "password"}
                    fullWidth
                    margin="normal"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyPress={handleKeyPress}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Lock color="primary" />
                            </InputAdornment>
                        ),
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    onClick={() => setShowPassword(!showPassword)}
                                    edge="end"
                                >
                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                </IconButton>
                            </InputAdornment>
                        ),
                    }}
                    sx={{
                        '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover fieldset': {
                                borderColor: '#0088cc',
                            },
                            '&.Mui-focused fieldset': {
                                borderColor: '#0088cc',
                            },
                        }
                    }}
                />

                <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    onClick={handleLogin}
                    disabled={loading}
                    startIcon={loading ? <CircularProgress size={20} color="inherit" /> : null}
                    sx={{
                        mt: 3,
                        mb: 2,
                        py: 1.5,
                        borderRadius: 2,
                        background: 'linear-gradient(45deg, #0088cc, #00a2ff)',
                        fontSize: '1rem',
                        fontWeight: 'bold',
                        textTransform: 'none',
                        boxShadow: '0 4px 15px rgba(0, 136, 204, 0.3)',
                        '&:hover': {
                            boxShadow: '0 6px 20px rgba(0, 136, 204, 0.4)',
                            transform: 'translateY(-1px)',
                            background: 'linear-gradient(45deg, #0077b3, #0099e6)',
                        },
                        '&:disabled': {
                            background: 'rgba(0, 136, 204, 0.5)',
                        },
                        transition: 'all 0.3s ease'
                    }}
                >
                    {loading ? "Kirilmoqda..." : "Kirish"}
                </Button>

                <Box sx={{ textAlign: 'center', mt: 2 }}>
                    <Typography
                        variant="body2"
                        sx={{
                            color: 'text.secondary',
                            mb: 1
                        }}
                    >
                        Hisobingiz yo'qmi?
                    </Typography>
                    <Button
                        variant="outlined"
                        size="medium"
                        onClick={() => navigate("/register")}
                        sx={{
                            borderRadius: 2,
                            textTransform: 'none',
                            fontSize: '0.9rem',
                            color: '#0088cc',
                            borderColor: '#0088cc',
                            px: 3,
                            '&:hover': {
                                background: 'rgba(0, 136, 204, 0.1)',
                                borderColor: '#0077b3',
                                transform: 'translateY(-1px)',
                            },
                            transition: 'all 0.3s ease'
                        }}
                    >
                        Ro'yxatdan o'tish
                    </Button>
                </Box>

                <Typography
                    variant="caption"
                    display="block"
                    align="center"
                    sx={{
                        mt: 3,
                        color: 'text.secondary',
                        fontSize: '0.75rem'
                    }}
                >
                    Telegram Clone - Xavfsiz messaging platformasi
                </Typography>
            </Paper>
        </Box>
    );
}