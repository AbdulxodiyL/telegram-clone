const express = require('express');
const router = express.Router();
const authController = require('../controler/auth.controller');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 📁 uploads papkasini avtomatik yaratish

const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// 📸 Multer sozlamasi
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        const ext = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + Date.now() + ext);
    },
});
const upload = multer({ storage });

router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/profile', authController.profile);
router.get('/users', authController.getAllUsers);
router.put('/edit', upload.single('avatar'), authController.editUser);
router.delete('/delete', authController.deleteUser);
router.get('/user/:id', authController.getUserById);

module.exports = router;
