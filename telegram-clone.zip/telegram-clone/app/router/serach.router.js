const express = require('express');
const router = express.Router();
const searchController = require('../controler/search.controller');

router.get('/users', searchController.searchByUsername);
router.get('/users/email', searchController.searchByEmail);
router.get('/users/id', searchController.searchById);

module.exports = router;