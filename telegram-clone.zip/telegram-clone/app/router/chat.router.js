const express = require('express');
const router = express.Router();
const chatController = require('../controler/chat.controller');

router.get('/', chatController.getAllChats);
router.get('/:id', chatController.getChatById);
router.get('/username/:username', chatController.getChatsByUsername);
router.get('/email/:email', chatController.getChatsByEmail);
router.post('/', chatController.createChat);
router.get('/conversation/:senderId/:receiverId', chatController.getConversation);

module.exports = router;