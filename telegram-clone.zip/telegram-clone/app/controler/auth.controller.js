const User = require('../models/auth.models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({ username, email, password: hashedPassword });
        res.status(201).json({ message: 'Foydalanuvchi ro\'yxatdan o\'tdi', user });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });
        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ error: 'Parol noto\'g\'ri' });

        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        res.json({ message: 'Kirish muvaffaqiyatli', token });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.profile = async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) return res.status(401).json({ error: 'Token yo‘q' });

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id, {
            attributes: ['id', 'username', 'email', 'bio', 'avatar', 'createdAt', 'updatedAt']
        });

        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
        res.json({ user });
    } catch (error) {
        res.status(401).json({ error: 'Token noto‘g‘ri yoki eskirgan' });
    }
};


exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.findAll({ attributes: ['id', 'username', 'email', 'createdAt', 'updatedAt'] });
        res.json({ users });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.editUser = async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) return res.status(401).json({ error: 'Token yo‘q' });
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        const { username, email, password, bio } = req.body || {};
        const updateData = {};

        if (username) updateData.username = username;
        if (email) updateData.email = email;
        if (password) updateData.password = await bcrypt.hash(password, 10);
        if (bio) updateData.bio = bio;

        if (req.file) {
            updateData.avatar = `/uploads/${req.file.filename}`;
        }

        await User.update(updateData, { where: { id: decoded.id } });
        const updatedUser = await User.findByPk(decoded.id);

        res.json({
            message: 'Foydalanuvchi ma’lumotlari yangilandi',
            user: updatedUser,
        });
    } catch (error) {
        console.error('editUser xatosi:', error);
        res.status(400).json({ error: error.message });
    }
};



exports.deleteUser = async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) return res.status(401).json({ error: 'Token yo\'q' });
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        await User.destroy({ where: { id: decoded.id } });
        res.json({ message: 'Foydalanuvchi o\'chirildi' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
exports.getUserById = async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id, {
            attributes: ['id', 'username', 'email', 'bio', 'avatar', 'createdAt', 'updatedAt']
        });
        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
        res.json({ user });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};