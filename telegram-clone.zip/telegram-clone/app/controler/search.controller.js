const User = require('../models/auth.models');
const { Op } = require('sequelize');

exports.searchByUsername = async (req, res) => {
    try {
        const { username } = req.query;
        if (!username) return res.status(400).json({ error: 'username kiritilmadi' });
        const users = await User.findAll({
            where: {
                username: { [Op.iLike]: `%${username}%` }
            },
            attributes: ['id', 'username', 'email', 'createdAt', 'updatedAt']
        });
        res.json({ users });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.searchByEmail = async (req, res) => {
    try {
        const { email } = req.query;
        if (!email) return res.status(400).json({ error: 'email kiritilmadi' });
        const users = await User.findAll({
            where: {
                email: { [Op.iLike]: `%${email}%` }
            },
            attributes: ['id', 'username', 'email', 'createdAt', 'updatedAt']
        });
        res.json({ users });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.searchById = async (req, res) => {
    try {
        const { id } = req.query;
        if (!id) return res.status(400).json({ error: 'id kiritilmadi' });
        const user = await User.findByPk(id, {
            attributes: ['id', 'username', 'email', 'createdAt', 'updatedAt']
        });
        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
        res.json({ user });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};