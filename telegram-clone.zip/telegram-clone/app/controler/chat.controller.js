const Chat = require('../models/chat.models');
const User = require('../models/auth.models');
const { Op } = require('sequelize');

// === Barcha chatlar ===
exports.getAllChats = async (req, res) => {
    try {
        const chats = await Chat.findAll({ order: [['createdAt', 'ASC']] });
        res.json({ chats });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// === Chatni ID orqali olish ===
exports.getChatById = async (req, res) => {
    try {
        const chat = await Chat.findByPk(req.params.id);
        if (!chat) return res.status(404).json({ error: 'Chat topilmadi' });
        res.json({ chat });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// === Username bo‘yicha chatlar ===
exports.getChatsByUsername = async (req, res) => {
    try {
        const user = await User.findOne({ where: { username: req.params.username } });
        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });

        const chats = await Chat.findAll({
            where: {
                [Op.or]: [
                    { senderId: user.id },
                    { receiverId: user.id }
                ]
            },
            order: [['createdAt', 'ASC']]
        });

        res.json({ chats });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// === Email bo‘yicha chatlar ===
exports.getChatsByEmail = async (req, res) => {
    try {
        const user = await User.findOne({ where: { email: req.params.email } });
        if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });

        const chats = await Chat.findAll({
            where: {
                [Op.or]: [
                    { senderId: user.id },
                    { receiverId: user.id }
                ]
            },
            order: [['createdAt', 'ASC']]
        });

        res.json({ chats });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// === Yangi chat yaratish (duplicate safe) ===
exports.createChat = async (req, res) => {
    try {
        const { message, senderId, receiverId } = req.body;

        if (!message || !senderId || !receiverId) {
            return res.status(400).json({ error: 'Message, senderId va receiverId majburiy' });
        }

        const chat = await Chat.create({ message, senderId, receiverId });
        res.status(201).json({ chat });
    } catch (error) {
        console.error("❌ Xabar yaratishda xato:", error);
        res.status(500).json({ error: error.message });
    }
};


// === Conversation (ikki foydalanuvchi o‘rtasidagi xabarlar) ===
exports.getConversation = async (req, res) => {
    try {
        const senderId = parseInt(req.params.senderId);
        const receiverId = parseInt(req.params.receiverId);

        if (isNaN(senderId) || isNaN(receiverId)) {
            return res.status(400).json({ error: 'Invalid senderId yoki receiverId' });
        }

        const messages = await Chat.findAll({
            where: {
                [Op.or]: [
                    { senderId, receiverId },
                    { senderId: receiverId, receiverId: senderId }
                ]
            },
            order: [['createdAt', 'ASC']]
        });

        res.json({ messages });
    } catch (error) {
        console.error("❌ Conversation olishda xato:", error);
        res.status(500).json({ error: error.message });
    }
};
